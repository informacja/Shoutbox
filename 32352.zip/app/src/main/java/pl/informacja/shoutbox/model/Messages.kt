package pl.informacja.shoutbox.model


class Message(
    var content: String?,
    var login: String?,
    var date: String?,
    var id: String?
)

//class Messages(val content: String, val login: String, val date: String, val id:String) {
//}