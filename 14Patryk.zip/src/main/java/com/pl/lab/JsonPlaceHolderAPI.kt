package com.pl.lab

import com.pl.lab.classes.MessageFromServer
import retrofit2.Call
import retrofit2.http.*


interface JsonPlaceHolderAPI {

    @GET("shoutbox/messages")
    fun getMessages(): Call <ArrayList<MessageFromServer>>

    @PUT("shoutbox/message/{id}")
    fun sendEdited(@Path( "id") id:String,@Body message :MessageFromServer): Call <MessageFromServer>

    @POST("shoutbox/message")
    fun sendNew(@Body message: MessageFromServer): Call <MessageFromServer>

    @DELETE("shoutbox/message/{id}")
    fun deleteMessage(@Path("id") id:String): Call <MessageFromServer>
}