package com.pl.lab

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.navigation.findNavController
import androidx.navigation.ui.AppBarConfiguration
import androidx.navigation.ui.navigateUp
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.google.android.material.navigation.NavigationView
import com.pl.lab.ui.listOfMessages.ListOfMessages
import com.pl.lab.ui.newMessage.VEMessageFragment
import com.pl.lab.ui.newMessage.NewMessage


class Chat : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {

    private lateinit var appBarConfiguration: AppBarConfiguration
    lateinit var login:String
    lateinit var drawerLayout: DrawerLayout
    private lateinit var lamFragment: VEMessageFragment
    private lateinit var lomFragment: ListOfMessages

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        drawerLayout = findViewById(R.id.drawer_layout)
        val navView: NavigationView = findViewById(R.id.nav_view)
        navView.setNavigationItemSelectedListener(this)
        val toggle: ActionBarDrawerToggle =
            ActionBarDrawerToggle(this,drawerLayout,toolbar,R.string.navigation_drawer_open,R.string.navigation_drawer_close)

        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()

        val fab: FloatingActionButton = findViewById(R.id.fab)
        fab.setOnClickListener { view ->
            fab.visibility = View.INVISIBLE
            val dialog = NewMessage()
            dialog.show(supportFragmentManager,"dialog")
        }

        lomFragment = ListOfMessages()
        lamFragment = VEMessageFragment()

        supportFragmentManager.beginTransaction().replace(R.id.nav_host_fragment, ListOfMessages()).commit()
        navView.setCheckedItem(R.id.nav_home)


        val headerView: View = navView.getHeaderView(0)

        val intent: Intent = intent
        val nickName: TextView = headerView.findViewById(R.id.nickView);

        login = intent.getStringExtra("LOGIN_NAME")
        intent.putExtra("LOGIN_NAME2",login)
        nickName.text = "• " + login

    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        if(hasFocus!=false) {
            val fab: FloatingActionButton = findViewById(R.id.fab)
            fab.visibility = View.VISIBLE
            val navView: NavigationView = findViewById(R.id.nav_view)
            navView.setCheckedItem(R.id.nav_home)
            overridePendingTransition(R.anim.enter_from_right, R.anim.exit_to_right)
        }
        super.onWindowFocusChanged(hasFocus)
    }

    override fun onBackPressed() {
        if(drawerLayout.isDrawerOpen(GravityCompat.START)){
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        // Inflate the menu; this adds items to the action bar if it is present.
        menuInflater.inflate(R.menu.chat, menu)
        return true
    }

    override fun onSupportNavigateUp(): Boolean {
        val navController = findNavController(R.id.nav_host_fragment)
        return navController.navigateUp(appBarConfiguration) || super.onSupportNavigateUp()
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {

        if(item.itemId == R.id.nav_home){
            supportFragmentManager.beginTransaction()
                .replace(R.id.nav_host_fragment, ListOfMessages()).commit()
            val fab: FloatingActionButton = findViewById(R.id.fab)
            fab.visibility = View.VISIBLE

        }
        if(item.itemId == R.id.nav_logout){
            val intent2: Intent = Intent(this,MainActivity::class.java)
            saveData("")
            startActivity(intent2)
            finish()
        }
        if(item.itemId == R.id.nav_newMsg){
            val dialog = NewMessage()
            dialog.show(supportFragmentManager,"dialog")
            val fab: FloatingActionButton = findViewById(R.id.fab)
            fab.visibility=View.INVISIBLE
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true
    }

    private fun saveData(name: String) {
        val sharedPreferences =
            getSharedPreferences("shared preferences", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("LOGIN_KEY", name)
        editor.apply()
    }

}
