package com.pl.lab.classes

import java.io.Serializable

class MessageFromServer(
    Login: String,
    Content: String
): Serializable{
    var login:String = Login
    var date:String? = null
    var content:String = Content
    var id:String? = null
}