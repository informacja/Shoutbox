package com.pl.lab.classes

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.annotation.NonNull
import androidx.recyclerview.widget.RecyclerView
import com.pl.lab.R
import com.pl.lab.classes.MessageAdapter.MessageViewHolder
import org.w3c.dom.Text


class MessageAdapter(private val exampleMessages: ArrayList<MessageFromServer>) :
    RecyclerView.Adapter<MessageViewHolder>() {

    private var mListener: OnItemClickListener? = null

    interface OnItemClickListener {
        fun onItemClick(position: Int)
    }

    fun setOnItemClickListener(listener: OnItemClickListener) {
        mListener = listener
    }

    class MessageViewHolder(
        itemView: View,
        listener: OnItemClickListener?
    ):RecyclerView.ViewHolder(itemView) {
        val mLogin: TextView = itemView.findViewById(R.id.NickField)
        val mDate: TextView = itemView.findViewById(R.id.DataField)
        val mText: TextView = itemView.findViewById(R.id.MessegeField)
        val mTime: TextView = itemView.findViewById(R.id.TimeField)
        init{
        itemView.setOnClickListener {
            if (listener != null) {
                val position: Int = getAdapterPosition()
                if (position != RecyclerView.NO_POSITION) {
                    listener.onItemClick(position)
                }
            }
        } }
    }

    override fun onCreateViewHolder(@NonNull parent: ViewGroup, viewType: Int): MessageViewHolder {

        val v = LayoutInflater.from(parent.context).inflate(R.layout.content_item, parent, false)

        return MessageViewHolder(v,mListener)
    }

    override fun onBindViewHolder(@NonNull holder: MessageViewHolder, position: Int) {
        val currentItem = exampleMessages[position]
        var tmpLogin = currentItem.login
        if(tmpLogin.length>14) {
            tmpLogin = tmpLogin!!.substring(0, 14)
        }
        holder.mLogin.text = tmpLogin
        var data = currentItem.date
        var time = data!!.substring(11,19).replace("T"," ")
        holder.mTime.text = time
        data = data!!.substring(0,10)
        holder.mDate.text = data
        var msg = currentItem.content;
        if(msg.length>50){
            msg= currentItem.content.substring(0,50)+" ..."
        }
        holder.mText.text = msg
    }

    override fun getItemCount(): Int {
        return exampleMessages.size
    }

    fun getItem(position: Int): MessageFromServer {
        return exampleMessages[position]
    }

    fun removeAt(position: Int) {
        exampleMessages.removeAt(position)
        notifyItemRemoved(position)
    }

}