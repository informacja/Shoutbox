package com.pl.lab

import android.content.Context
import android.content.Intent
import android.net.ConnectivityManager
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.textfield.TextInputLayout
import java.io.UnsupportedEncodingException

class MainActivity : AppCompatActivity() {

    private lateinit var nick: TextInputLayout;
    private lateinit var login: String
    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        nick = findViewById(R.id.nick_container)
        loadData()
        if (!login.isBlank() && haveNetwork()) {
            intent = Intent(this, Chat::class.java)
            intent.putExtra("LOGIN_NAME", login)
            startActivity(intent)
        }
    }

    @Throws(UnsupportedEncodingException::class)
    fun sendText(view: View?) {
        intent = Intent(this, Chat::class.java)
        if (haveNetwork()) {
            if (!nick.editText!!.text.isBlank()) {
                nick.error = null
                login = nick.editText!!.text.toString()
                intent.putExtra("LOGIN_NAME", login)
                startActivity(intent)
                saveData(login)
            } else {
                nick.error = getString(R.string.need_login)
            }
        } else {
            val toast = Toast.makeText(applicationContext, getString(R.string.no_internet), Toast.LENGTH_SHORT)
            toast.setGravity(Gravity.TOP, 0, 300)
            toast.show()
        }
    }

    private fun haveNetwork(): Boolean {
        var have_WIFI = false
        var have_MobileData = false
        val connectivityManager =
            getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfos = connectivityManager.allNetworkInfo
        for (info in networkInfos) {
            if (info.typeName.equals("WIFI", ignoreCase = true))
                if (info.isConnected) have_WIFI = true
            if (info.typeName
                        .equals("MOBILE DATA", ignoreCase = true)
                    ) if (info.isConnected) have_MobileData = true
                }
                return have_WIFI || have_MobileData
            }

    private fun saveData(name: String) {
        val sharedPreferences =
            getSharedPreferences("shared preferences", Context.MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        editor.putString("LOGIN_KEY", name)
        editor.apply()
    }

    private fun loadData() {
        val sharedPreferences =
            getSharedPreferences("shared preferences", Context.MODE_PRIVATE)
        login = sharedPreferences.getString("LOGIN_KEY", "").toString();
        nick.editText!!.setText(login)
    }

}


