package com.pl.lab.ui.listOfMessages

import android.content.Context
import android.graphics.PorterDuff
import android.net.ConnectivityManager
import android.os.Bundle
import android.os.Handler
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentManager
import androidx.fragment.app.FragmentTransaction
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.pl.lab.JsonPlaceHolderAPI
import com.pl.lab.R
import com.pl.lab.classes.MessageAdapter
import com.pl.lab.classes.MessageFromServer
import com.pl.lab.classes.SwipeToDeleteCallBack
import com.pl.lab.ui.newMessage.VEMessageFragment
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class ListOfMessages : Fragment() {

    private lateinit var messageViewModel: LisOfMessagesViewModel
    private val baseURL:String = "http://tgryl.pl/"
    private lateinit var pageMessages:ArrayList<MessageFromServer>
    private var swipeRefresh: SwipeRefreshLayout? = null
    private lateinit var jsonPlaceholderApi: JsonPlaceHolderAPI
    private lateinit var mRecyclerView: RecyclerView
    private lateinit var mLayoutManager: RecyclerView.LayoutManager
    private var mAdapter:MessageAdapter? = null
    private var userLogin:String? = null

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        messageViewModel =
            ViewModelProviders.of(this).get(LisOfMessagesViewModel::class.java)
        val root = inflater.inflate(R.layout.fragment_message, container, false)

        val retrofit: Retrofit = Retrofit.Builder().baseUrl(baseURL)
            .addConverterFactory(GsonConverterFactory.create()).build()

        jsonPlaceholderApi = retrofit.create(JsonPlaceHolderAPI::class.java)

        val preferences =
            this.requireActivity().getSharedPreferences("shared preferences", Context.MODE_PRIVATE)
        userLogin = preferences.getString("LOGIN_KEY", "").toString();

        mRecyclerView= root.findViewById(R.id.recyclerView)
        if(haveNetwork()) {
            loadData()
            val refreshHandler = Handler()
            val runnable: Runnable = object : Runnable {
                override fun run() {
                    loadData()
                    refreshHandler.postDelayed(this, 30 * 1000)
                }
            }
            refreshHandler.postDelayed(runnable, 30 * 1000)
        } else {
            showToast(getString(R.string.loading_error))
        }

        swipeRefresh = root.findViewById(R.id.swipeRefresh)
        swipeRefresh!!.setOnRefreshListener {
            if(haveNetwork()) {
                loadData()
                swipeRefresh!!.isRefreshing = false
                showToast(getString(R.string.refreshed))
            } else {
                showToast(getString(R.string.no_internet))
                swipeRefresh!!.isRefreshing = false
            }
        }

        messageViewModel.text.observe(viewLifecycleOwner, Observer {
        })
        return root
    }

    private fun buildRecyclerView() {

            mRecyclerView.setHasFixedSize(true)
            mLayoutManager = LinearLayoutManager(context)
            mAdapter = MessageAdapter(pageMessages)
            mRecyclerView.layoutManager = mLayoutManager
            mRecyclerView.adapter = mAdapter
            mAdapter!!.setOnItemClickListener(object : MessageAdapter.OnItemClickListener {
                override fun onItemClick(position: Int) {
                    val bundle = Bundle()
                    bundle.putSerializable("message", pageMessages[position])

                    val fragment: Fragment = VEMessageFragment()

                    fragment.arguments = bundle

                    val fragmentManager: FragmentManager? = fragmentManager
                    val ft: FragmentTransaction = fragmentManager!!.beginTransaction()
                    ft.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_right)
                    ft.replace(R.id.nav_host_fragment, fragment)
                    ft.addToBackStack("")
                    ft.commit()
                }
            })
            val swipeHandler = object : SwipeToDeleteCallBack(context) {
                override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                    if(haveNetwork()) {
                        val adapter = mRecyclerView.adapter as MessageAdapter
                        val tempMsg = adapter.getItem(viewHolder.adapterPosition)
                        if (userLogin.equals(tempMsg.login)) {
                            deleteMessage(tempMsg.id!!)
                            adapter.removeAt(viewHolder.adapterPosition)
                        } else {
                            showToast(getString(R.string.not_ur_post))
                            loadData()
                        }
                    } else {
                        loadData()
                        showToast(getString(R.string.no_internet))
                    }
                }
            }

            val itemTouchHelper = ItemTouchHelper(swipeHandler)
            itemTouchHelper.attachToRecyclerView(mRecyclerView)
    }

    private fun loadData() {

        val call: Call<ArrayList<MessageFromServer>> = jsonPlaceholderApi.getMessages()

        call.enqueue(object : Callback<ArrayList<MessageFromServer>> {
            override fun onFailure(call: Call<ArrayList<MessageFromServer>>,
                                   t: Throwable
            ) {
                buildRecyclerView();
            }
            override fun onResponse(
                call: Call<ArrayList<MessageFromServer>>,
                response: Response<ArrayList<MessageFromServer>>
            ) {
                pageMessages= response.body()!!
                pageMessages.reverse()
                buildRecyclerView()
            }
        })
    }

    override fun onResume() {
        loadData()
        super.onResume()
    }

    private fun deleteMessage(id:String) {

        val call = jsonPlaceholderApi.deleteMessage(id)

        call.enqueue(object : Callback<MessageFromServer> {
            override fun onFailure(call: Call<MessageFromServer>,
                                   t: Throwable
            ) {
            }
            override fun onResponse(
                call: Call<MessageFromServer>,
                response: Response<MessageFromServer>
            ) {
                if (!response.isSuccessful) {
                    println("Code: " + response.code())
                    return
                }
                showToast(getString(R.string.deleted))
            }
        })
    }

    private fun haveNetwork(): Boolean {
        var have_WIFI = false
        var have_MobileData = false
        val connectivityManager =
            requireActivity().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfos = connectivityManager.allNetworkInfo
        for (info in networkInfos) {
            if (info.typeName
                    .equals("WIFI", ignoreCase = true)
            ) if (info.isConnected) have_WIFI = true
            if (info.typeName
                    .equals("MOBILE DATA", ignoreCase = true)
            ) if (info.isConnected) have_MobileData = true
        }
        return have_WIFI || have_MobileData
    }

    fun showToast(string: String){
        val toast: Toast = Toast.makeText(context, string, Toast.LENGTH_SHORT)
        val view = toast.view
        view.background
            .setColorFilter(resources.getColor(R.color.colorPrimaryDark), PorterDuff.Mode.SRC_IN)

        val text: TextView = view.findViewById(android.R.id.message)
        text.setTextColor(resources.getColor(android.R.color.white))

        toast.show()
    }
}
