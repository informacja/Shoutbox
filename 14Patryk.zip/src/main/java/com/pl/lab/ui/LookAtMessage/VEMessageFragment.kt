package com.pl.lab.ui.newMessage

import android.content.Context
import android.graphics.Color
import android.graphics.PorterDuff
import android.net.ConnectivityManager
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProviders
import com.pl.lab.JsonPlaceHolderAPI
import com.pl.lab.R
import com.pl.lab.classes.MessageFromServer
import com.pl.lab.ui.listOfMessages.ListOfMessages
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory


class VEMessageFragment : Fragment() {


    private lateinit var lookAtMessageFragment: ViewerEditorMessageViewModel
    private lateinit var jsonPlaceholderApi: JsonPlaceHolderAPI
    private val baseURL:String = "http://tgryl.pl/"
    private lateinit var loginF:TextView
    private lateinit var dateF:TextView
    private lateinit var textF:TextView
    private lateinit var timeF:TextView
    private lateinit var delBut:Button
    private lateinit var edBut:Button
    private lateinit var acceptBut:Button
    private var message:MessageFromServer? = null
    private var userLogin:String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (arguments != null) {
            message = arguments?.getSerializable("message") as MessageFromServer?
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        lookAtMessageFragment = ViewModelProviders.of(this).get(ViewerEditorMessageViewModel::class.java)
        val root = inflater.inflate(R.layout.editviewer_fragment, container, false)
        loginF = root.findViewById(R.id.nmLoginField)
        dateF = root.findViewById(R.id.lamDataField)
        textF = root.findViewById(R.id.nmTextField)
        timeF = root.findViewById(R.id.lamTimeField)
        var data = message?.date
        var time = data!!.substring(11,19).replace("T"," ")
        data = data!!.substring(0, 10)

        timeF.text = time
        loginF.text = message?.login
        dateF.text = data
        textF.text = message?.content

        delBut = root.findViewById(R.id.iamDelBut)
        edBut = root.findViewById(R.id.lamEditBut)
        acceptBut = root.findViewById(R.id.changeBut)

        val preferences =
            this.requireActivity().getSharedPreferences("shared preferences", Context.MODE_PRIVATE)
        userLogin = preferences.getString("LOGIN_KEY", "").toString();

        if (!userLogin.equals(message?.login)) {
            delBut.isEnabled = false
            edBut.isEnabled = false
        }

        val retrofit = Retrofit.Builder().baseUrl(baseURL)
            .addConverterFactory(
                GsonConverterFactory
                    .create()
            )
            .build()
        jsonPlaceholderApi = retrofit.create(JsonPlaceHolderAPI::class.java)

        edBut.setOnClickListener {
            if(haveNetwork()){
                acceptBut.visibility = View.VISIBLE
                textF.isFocusable = true
                textF.setBackgroundColor(Color.WHITE)
                acceptBut.setOnClickListener {

                    val tempMsg = MessageFromServer(userLogin!!, textF.text.toString())

                    editMessage(message?.id!!, tempMsg)

                    val fragment: Fragment = ListOfMessages()
                    val ft: FragmentTransaction = requireFragmentManager().beginTransaction()
                    ft.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_right)
                    ft.replace(R.id.nav_host_fragment, fragment)
                    ft.commit()
                }
            } else {
                showToast(getString(R.string.edited))
            }
        }


        delBut.setOnClickListener {
            if(haveNetwork()) {
                deleteMessage(message?.id!!)

                val fragment: Fragment = ListOfMessages()
                val ft: FragmentTransaction = requireFragmentManager().beginTransaction()
                ft.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_right)
                ft.replace(R.id.nav_host_fragment, fragment)
                ft.commit()
            } else {
                showToast(getString(R.string.edited))
            }

        }

        lookAtMessageFragment.text.observe(viewLifecycleOwner, Observer {
        })

        return root
    }

    private fun editMessage(id:String ,message: MessageFromServer) {

        val call = jsonPlaceholderApi.sendEdited(id,message)

        call.enqueue(object : Callback<MessageFromServer> {
            override fun onFailure(call: Call<MessageFromServer>,
                                   t: Throwable
            ) {
            }
            override fun onResponse(
                call: Call<MessageFromServer>,
                response: Response<MessageFromServer>
            ) {
                if (!response.isSuccessful) {
                    println("Code: " + response.code())
                    return
                }
                showToast(getString(R.string.edited))
            }
        })
    }

    private fun deleteMessage(id:String) {

        val call = jsonPlaceholderApi.deleteMessage(id)

        call.enqueue(object : Callback<MessageFromServer> {
            override fun onFailure(call: Call<MessageFromServer>,
                                   t: Throwable
            ) {
            }
            override fun onResponse(
                call: Call<MessageFromServer>,
                response: Response<MessageFromServer>
            ) {
                if (!response.isSuccessful) {
                    println("Code: " + response.code())
                    return
                }
                showToast(getString(R.string.deleted))
            }
        })
    }

    private fun haveNetwork(): Boolean {
        var have_WIFI = false
        var have_MobileData = false
        val connectivityManager =
            requireActivity().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfos = connectivityManager.allNetworkInfo
        for (info in networkInfos) {
            if (info.typeName
                    .equals("WIFI", ignoreCase = true)
            ) if (info.isConnected) have_WIFI = true
            if (info.typeName
                    .equals("MOBILE DATA", ignoreCase = true)
            ) if (info.isConnected) have_MobileData = true
        }
        return have_WIFI || have_MobileData
    }

    fun showToast(string: String){
        val toast: Toast = Toast.makeText(context, string, Toast.LENGTH_SHORT)
        val view = toast.view
        view.background
            .setColorFilter(resources.getColor(R.color.colorPrimaryDark), PorterDuff.Mode.SRC_IN)

        val text: TextView = view.findViewById(android.R.id.message)
        text.setTextColor(resources.getColor(android.R.color.white))

        toast.show()
    }
}
