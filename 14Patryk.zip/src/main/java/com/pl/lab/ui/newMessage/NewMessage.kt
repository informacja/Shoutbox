package com.pl.lab.ui.newMessage

import android.content.Context
import android.graphics.PorterDuff
import android.net.ConnectivityManager
import androidx.lifecycle.ViewModelProviders
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.FragmentTransaction
import androidx.lifecycle.Observer
import com.google.android.material.textfield.TextInputLayout
import com.pl.lab.JsonPlaceHolderAPI

import com.pl.lab.R
import com.pl.lab.classes.MessageFromServer
import com.pl.lab.ui.listOfMessages.ListOfMessages
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class NewMessage : DialogFragment() {


    private lateinit var newMessageViewModel: ViewerEditorMessageViewModel
    private lateinit var loginField: TextView
    private lateinit var textField: TextInputLayout
    private lateinit var sendBut: Button
    private var userLogin:String? = null
    private lateinit var jsonPlaceholderApi: JsonPlaceHolderAPI
    private val baseURL:String = "http://tgryl.pl/"


    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {

        newMessageViewModel = ViewModelProviders.of(this).get(ViewerEditorMessageViewModel::class.java)
        val root = inflater.inflate(R.layout.new_message_dialog, container, false)

        val preferences =
            this.requireActivity().getSharedPreferences("shared preferences", Context.MODE_PRIVATE)
        userLogin = preferences.getString("LOGIN_KEY", "").toString()

        loginField = root.findViewById(R.id.nmLoginField)
        textField = root.findViewById(R.id.nmTextField)
        sendBut = root.findViewById(R.id.nmSendButton)
        loginField.text = userLogin

        textField.editText!!.addTextChangedListener(object : TextWatcher{
            override fun afterTextChanged(s: Editable?) {}
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val x = textField!!.editText!!.text
                sendBut.setEnabled(!x.isEmpty())
            }
        })
        val retrofit = Retrofit.Builder().baseUrl(baseURL)
            .addConverterFactory(
                GsonConverterFactory
                    .create()
            )
            .build()
        jsonPlaceholderApi = retrofit.create(JsonPlaceHolderAPI::class.java)

        sendBut.setOnClickListener(){
            if(haveNetwork()) {

                val tempMsg = MessageFromServer(userLogin!!, textField.editText!!.text.toString())

                sendMessage(tempMsg)

                val fragment: Fragment = ListOfMessages()
                val ft: FragmentTransaction = requireFragmentManager().beginTransaction()
                ft.setCustomAnimations(R.anim.enter_from_right, R.anim.exit_to_right)
                ft.replace(R.id.nav_host_fragment, fragment)
                ft.commit()
            } else {
                showToast(getString(R.string.no_internet))
            }
        }
        newMessageViewModel.text.observe(viewLifecycleOwner, Observer {
        })

        return root
    }

    private fun sendMessage(message: MessageFromServer) {

        val call = jsonPlaceholderApi.sendNew(message)

        call.enqueue(object : Callback<MessageFromServer> {
            override fun onFailure(call: Call<MessageFromServer>,
                                   t: Throwable
            ) {
            }
            override fun onResponse(
                call: Call<MessageFromServer>,
                response: Response<MessageFromServer>
            ) {
                if (!response.isSuccessful) {
                    println("Code: " + response.code())
                    return
                }
                showToast(getString(R.string.sent))
                dialog!!.dismiss()
            }
        })
    }

    private fun haveNetwork(): Boolean {
        var have_WIFI = false
        var have_MobileData = false
        val connectivityManager =
            requireActivity().getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val networkInfos = connectivityManager.allNetworkInfo
        for (info in networkInfos) {
            if (info.typeName
                    .equals("WIFI", ignoreCase = true)
            ) if (info.isConnected) have_WIFI = true
            if (info.typeName
                    .equals("MOBILE DATA", ignoreCase = true)
            ) if (info.isConnected) have_MobileData = true
        }
        return have_WIFI || have_MobileData
    }

    fun showToast(string: String){
        val toast: Toast = Toast.makeText(context, string, Toast.LENGTH_SHORT)
        val view = toast.view
        view.background
            .setColorFilter(resources.getColor(R.color.colorPrimaryDark), PorterDuff.Mode.SRC_IN)

        val text: TextView = view.findViewById(android.R.id.message)
        text.setTextColor(resources.getColor(android.R.color.white))

        toast.show()
    }


}
