package com.example.shoutbox.model

class MessageDto(val content: String, val login: String) {
}