package com.example.shoutbox.rest

import com.example.shoutbox.model.MessageDto
import retrofit2.Call
import retrofit2.http.*


interface RestApi {
    @Headers("Content-Type: application/json")
    @POST("message")
    fun sendMessage(@Body messageDto: MessageDto): Call<MessageDto>

//    @PUT("message/{id}")
//    fun editMessage(@Path("id") id: String?, @Body messageDto: MessageDto?): Call<MessageDto?>?

//    @PATCH("message/{id}")
//    fun patchEditMessage(@Path("id") id: String?, @Body messageDto: MessageDto?): Call<MessageDto?>?
}