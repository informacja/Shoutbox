package com.example.shoutbox

import android.content.Context
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class LoginActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val bSetLogin = findViewById<Button>(R.id.setLogin_button_login)
        val bShowLogin = findViewById<Button>(R.id.showLogin_button_login)
        val etLogin = findViewById<EditText>(R.id.login_editText_login)

        bShowLogin.setOnClickListener {
            val sharedPref = getSharedPreferences("SP_INFO", Context.MODE_PRIVATE)
            val name = sharedPref.getString("LOGIN","")
            Toast.makeText(this,"Your login is: " + name,Toast.LENGTH_LONG).show()
        }

        bSetLogin.setOnClickListener {
            val login = etLogin.text.toString()

            Toast.makeText(this,"Given login is: " + login,Toast.LENGTH_LONG).show()

            //Shared Preferences
            val sharedPref = getSharedPreferences("SP_INFO",Context.MODE_PRIVATE)
            val editor = sharedPref.edit()
            // putting data into sharedPref
            editor.putString("LOGIN", login)
            editor.apply()

            val intent = Intent(this, ShoutboxActivity::class.java)
            intent.putExtra("LOGIN", login)
            startActivity(intent)
        }
    }
}
