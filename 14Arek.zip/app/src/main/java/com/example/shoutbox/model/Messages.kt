package com.example.shoutbox.model

class Messages(val content: String, val login: String, val date: String, val id:String) {
}